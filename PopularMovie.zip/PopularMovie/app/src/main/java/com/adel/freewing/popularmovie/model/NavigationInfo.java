package com.adel.freewing.popularmovie.model;

import android.support.v4.app.Fragment;

public class NavigationInfo {
	public static Fragment fragment;
	public static String tag;
}
